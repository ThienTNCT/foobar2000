USE:

	If your dac/soundcard supports DSD playback through ASIO driver you can set up ASIO proxy:
	1. Run ASIOProxyInstall-X.X.X.exe to install foo_dsd_asio ASIO proxy driver.
	2. In foobar configure foo_dsd_asio proxy by selecting appropriate DSD compatible ASIO driver,
           DSD playback method, PCM/DSD to DSD conversion method (if needed) and DSD samplerate for PCM/DSD to DSD conversion.
	3. Select foo_dsd_asio as the output device.
	4. When troubleshooting tick "Trace to File" and select file name.


CHANGELOG:

	09/04/15:
	Version 0.8.3 - Stereo playback for mono DSD sources added.

	08/31/15:
	Version 0.8.2 - More detailed tracing, reset button added.

	08/25/15:
	Version 0.8.1 - Floating point SDMs.

	05/29/15:
	Version 0.7.3 - ASIO API tracing for downstream driver added.

	04/06/15:
	Version 0.7.2 - Bypass for unsupported samplerates in PCM to DSD converter.

	05/12/14:
	Version 0.7.1.2 - DSD/PCM switching fixed.

	05/08/14:
	Version 0.7.1.1 - Experimental: PCM upsampler is removed from DSD to DSD converter.

	05/05/14:
	Version 0.7.1 - Experimental: DSD to DSD converter, DSD path redesigned.

	07/29/13:
	Version 0.6.5 - Optional delay when switching between DSD and PCM modes.

	05/06/13:
	Version 0.6.4 - PCM to DSD multithreading, floating point SDMs.

	04/24/13:
	Version 0.6.3 - PCM to DSD converter fixed.

	04/22/13:
	Version 0.6.2 - Incompatibility with foo_input_sacd 0.6.4 fixed.

	03/26/13:
	Version 0.6.1 - Experimental: PCM to DSD for x48000 samplerates (requires comatible DSD DAC).

	10/31/12:
	Version 0.6.0 - Experimental: PCM to DSD converter added.


Maxim V.Anisiutkin <maxim.anisiutkin@gmail.com>
