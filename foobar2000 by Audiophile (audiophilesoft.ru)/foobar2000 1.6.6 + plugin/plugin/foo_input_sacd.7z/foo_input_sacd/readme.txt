NOTES:

	This plugin is capable to decode Super Audio CD ISO image content.
	This plugin contains code from SACD Ripper http://code.google.com/p/sacd-ripper/ project.


USE:

	Install foo_input_sacd.fb2k-component file and restart foobar. Then open *.ISO image file for playback.
	When needed adjust output volume and samplerate at File->Preferences->Tools->SACD.
	To use editable tags check it at File->Preferences->Tools->SACD.
	To playback SACD-R/RW discs create the new playlist, insert disc into DVD drive and drag-n-drop
	DVD drive letter (root folder) on the created playlist. Or, if UDF file system exists on SACD-R/RW,
	open MASTER1.TOC file.

	If your DAC supports DoP through ASIO/WASAPI/DS driver you can set up DSD playback:
	1. Open File->Preferences->Tools->SACD page.
	2. Select "DSD" for "Output Mode".
	3. Open File->Preferences->Playback->Output page.
	4. Select "DSD : <Driver Type> : <Device Name>".
	5. If your DAC doesn't support multichannel playback use "Downmix channels to stereo" DSP.
	If playback is in DSD mode you should get samplerates 2822400, 5644800, etc. and silence on VU Meter.
	
	For PCM playback it is possible to use custom FIR filters. Some filter samples are put in filters subfolder.


CHANGELOG:

	04/29/16:
	Version 0.9.7 - DoP for ASIO/WASAPI/DS, direct DSD for ASIO removed.

	12/09/15:
	Version 0.9.6 - Monoaural playback supported.

	11/23/15:
	Version 0.9.5 - Crash when no ASIO devices are presented in the system fixed.

	11/20/15:
	Version 0.9.4 - Device channel names/types in channel mapping fixed.

	11/13/15:
	Version 0.9.3 - DSD output trace into foobar console added.

	10/28/15:
	Version 0.9.2 - PCM overload fixed.

	10/27/15:
	Version 0.9.1 - ASIO handling changed.

	10/22/15:
	Version 0.9.0 - Sketchy: Direct DSD output for compatible ASIO devices (ASIO Proxy driver is not required).

	09/04/15:
	Version 0.8.4 - "dynamic range" tag unlinked.

	08/05/15:
	Version 0.8.3 - Replaygain info for linked stereo/multichannel tags fixed.

	08/04/15:
	Version 0.8.2 - Intel IPP in DSD to PCM converter, linked stereo/multichannel tags.

	06/30/15:
	Version 0.8.1 - Experimental: Multithreaded DSD to PCM converter.

	04/06/15:
	Version 0.7.8 - Log overloads in DSD to PCM converter.

	03/16/15:
	Version 0.7.7 - DSDIFF CRC chunk reading fixed.

	03/04/15:
	Version 0.7.6 - SACD metabase creation fixed.

	03/03/15:
	Version 0.7.5 - DSD samplerate fix for DSD USB DACs.

	02/10/15:
	Version 0.7.4 - New foobar2000 SDK, some fixes.

	09/29/14:
	Version 0.7.3 - DSDIFF odd chunk length bug fixed, Windows XP compatibility.
	
	09/25/14:
	Version 0.7.2 - Experimental: DSDIFF DST-compressed file playback with non-standart frame rates added.

	05/05/14:
	Version 0.7.1 - Experimental: DSD to DSD converter, DSD path redesigned.

	11/11/13:
	Version 0.6.6 - Random channel rearrangement in DSD mode (for stereo<->multi transition) fixed.
                        Installable filter description added.

	07/29/13:
	Version 0.6.5 - "Store Tags With ISO" option added.

	04/20/13:
	Version 0.6.4 - Windows XP compatibility, DSD512 playback fixed.

	04/17/13:
	Version 0.6.3 - Experimental: DSD256/512 DSDIFF and DSF file playback added (for PCM mode only).

	02/19/13:
	Version 0.6.2 - Phase inverse in Multistage (Fixed-Point) DSD to PCM converter fixed.

	11/01/12:
	Version 0.6.1 - DSF read last block fixed, ASIO proxy updated.

	08/28/12:
	Version 0.6.0 - Installable FIR filters for direct DSD to PCM decimation.

	06/27/12:
	Version 0.5.11 - Some protection against reading bad data added.

	05/28/12:
	Version 0.5.10 - Switching between DSD and PCM tracks fixed.

	05/21/12:
	Version 0.5.9 - ISO track codec type fixed.

	05/17/12:
	Version 0.5.8 - File buffering fixed.

	04/27/12:
	Version 0.5.7 - SACD-R/RW discs with UDF file system supported.

	04/24/12:
	Version 0.5.6 - Metabase reading fixed.

	04/23/12:
	Version 0.5.5 - SACD-R/RW discs playback added.

	04/14/12:
	Version 0.5.4 - On demand DST decoder initialization.

	03/21/12:
	Version 0.5.3 - DSD to PCM converter double precision modes added.

	03/19/12:
	Version 0.5.2 - DSDIFF DSD file reader fixed.

	03/15/12:
	Version 0.5.1 - Multitrack DSDIFF file playback fixed.

	03/07/12:
	Version 0.5.0 - DSF track playback added.

	03/01/12:
	Version 0.4.9 - DSD Autodetection removed. Better switching between DSD and PCM tracks.

	02/24/12:
	Version 0.4.8 - Mytek Stereo 192-DSD DAC is believed to be supported.

	02/23/12:
	Version 0.4.7 - Experimental: dCS DSD-over-PCM playback methods supported.

	02/18/12:
	Version 0.4.6 - Experimental: ASIO proxy driver for DSD direct playback.

	11/30/11:
	Version 0.4.5 - Editable ID3 tags for DSDIFF files implemented.

	11/28/11:
	Version 0.4.4 - Experimental: Multitrack DSDIFF files with Marker and ID3 chunks.

	11/11/11:
	Version 0.4.3 - Experimental: Exact search for DSDIFF files with DST Sound Index chunk added.

	11/11/11:
	Version 0.4.2 - Experimental: Lookup table based DST decoder design.

	10/31/11:
	Version 0.4.1 - DSDIFF playback crash fixed.

	10/21/11:
	Version 0.4.0 - Experimental: Direct DSD to PCM decimation with 30kHz cutoff.

	10/20/11:
	Version 0.3.14 - Multichannel playback area selection bug fixed.

	10/20/11:
	Version 0.3.13 - Gibbs artifacts reduced.

	10/17/11:
	Version 0.3.12 - Playback area is made preferable.

	10/17/11:
	Version 0.3.11 - Playback area selector added.

	10/14/11:
	Version 0.3.10 - Gapless playback (of ISO images) control added.

	10/02/11:
	Version 0.3.9 - Replaygain metadata dependence of "PCM Volume" control fixed.

	09/30/11:
	Version 0.3.8 - Large ISO (> 4GB) playback fixed.

	09/29/11:
	Version 0.3.7 - 44 kHz lowpass filter at 176400 samplerate added. Polyphase filters removed.

	09/26/11:
	Version 0.3.6 - Editable tags for ISO images added.

	09/25/11:
	Version 0.3.5 - Polyphase filters in DSD to PCM converter.

	09/20/11:
	Version 0.3.4 - Floating point SSE in DSD to PCM converter.

	09/18/11:
	Version 0.3.3 - NSL support in tags added.

	09/15/11:
	Version 0.3.2 - DSD to PCM converter fixed/floating point mode selector added.

	09/09/11:
	Version 0.3.1 - DSD to PCM converter performance a bit improved.

	09/07/11:
	Version 0.3.0 - Experimental: new DSD to PCM converter.

	08/25/11:
	Version 0.2.9 - DSDIFF tag reader added.

	08/25/11:
	Version 0.2.8 - DSD Fs128 support added.

	08/24/11:
	Version 0.2.7 - Tag mapping fixed.

	08/23/11:
	Version 0.2.6 - Seek in DSD mode fixed.

	08/22/11:
	Version 0.2.5 - Memory leak in DST decoder fixed.

	08/21/11:
	Version 0.2.4 - Experimental: SSE enabled DST decoder.

	08/06/11:
	Version 0.2.3 - Experimental: ASIO DSD/PCM autodetection.

	08/02/11:
	Version 0.2.2 - More seamless playback.

	08/01/11:
	Version 0.2.1 - Output PCM samplerate selector added.

	07/29/11:
	Version 0.2.0 - Experimental: ASIO direct DSD support added. PCM volume adjuct gauge added.

	07/19/11:
	Version 0.1.3 - DSDIFF file playback added.

	07/16/11:
	Version 0.1.2 - DSD track playback added.

	07/15/11:
	Version 0.1.1 - Reading of 2064 bytes sector images (Philips SuperAuthor) added.

	07/14/11:
	Version 0.1.0 - Playback added.

	07/07/11:
	Version 0.0.0 - DST decoder performance test, no real playback.


Maxim V.Anisiutkin <maxim.anisiutkin@gmail.com>
