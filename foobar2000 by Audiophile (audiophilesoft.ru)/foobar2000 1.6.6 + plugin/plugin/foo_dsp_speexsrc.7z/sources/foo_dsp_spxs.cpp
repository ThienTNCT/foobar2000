/* Copyright (c) 2008-10 lvqcl.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 *
 * 3. The name of the author may not be used to endorse or promote products
 * derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */ 

#include "foo_dsp_spxs.h"

const int buf_samples = 4096;

void dsp_spxs::init()
{
	t_dsp_spxs_params params;
	params.get_spxsconfig(cfg_);

	spxs_state_ = NULL;

	sample_rate_ = 0;
	channel_count_ = 0;
	channel_map_ = 0;
	
	buf_channels_ = 0;
	buffer_ = NULL;
	
	in_samples_accum_ = out_samples_gen_accum_ = 0;
}

dsp_spxs::dsp_spxs()
{
	init();
}

dsp_spxs::dsp_spxs(const t_dsp_spxs_params& params)
{
	init();
	params.get_spxsconfig(cfg_);
}

/*dsp_spxs::dsp_spxs(const dsp_preset& p_data)
{
	init();
	set_data(p_data);
}*/

bool dsp_spxs::set_data(const dsp_preset & p_data)
{
	t_dsp_spxs_params params;
	if (!params.set_data(p_data)) return false;
	params.get_spxsconfig(cfg_);
	return true;
}

dsp_spxs::~dsp_spxs()
{
	if (spxs_state_)
	{
		speex_resampler_destroy(spxs_state_);
		spxs_state_ = NULL;
	}
	delete[] buffer_;
	buffer_ = NULL;
}

void dsp_spxs::on_endoftrack(abort_callback & p_abort) { flushwrite(); }

void dsp_spxs::on_endofplayback(abort_callback & p_abort) { flushwrite(); }

void dsp_spxs::reinit(unsigned sample_rate, unsigned channel_count, unsigned channel_map)
{
	int spxs_error;

	if (buf_channels_ < channel_count)
	{
		buf_channels_ = channel_count;
		delete[] buffer_;
		buffer_ = new audio_sample[buf_samples*channel_count];
	}

	spxs_state_ = speex_resampler_init(channel_count, sample_rate, cfg_.outRate, cfg_.quality,  &spxs_error);
	if (spxs_state_ == NULL) { console::error(speex_resampler_strerror(spxs_error)); }
	speex_resampler_skip_zeros(spxs_state_);

	channel_count_ = channel_count; channel_map_ = channel_map; sample_rate_ = sample_rate;
	in_samples_accum_ = out_samples_gen_accum_ = 0;
}

bool dsp_spxs::on_chunk(audio_chunk * chunk, abort_callback & p_abort)
{
	spx_uint32_t in_samples_used, out_samples_gen;
	int spxs_error;

	unsigned channel_count = chunk->get_channels();
	unsigned channel_map = chunk->get_channel_config();
	unsigned sample_rate = chunk->get_sample_rate();
	t_size sample_count = chunk->get_sample_count();
	audio_sample * current = chunk->get_data();

	if (spxs_state_ == NULL) //uninitialized state
	{
		if (cfg_.is_no_resample(sample_rate)) return true;
		reinit(sample_rate, channel_count, channel_map);
	}
	else
	{
		if ((channel_count_ != channel_count) || (channel_map_ != channel_map) || (sample_rate_ != sample_rate))
		{	// number of channels or samplerate has changed - reinitialize
			flushwrite(); //here channel_count_, channel_map_ and sample_rate_ must have old values
			//spxs_state_ == NULL here
			if (cfg_.is_no_resample(sample_rate)) return true;
			reinit(sample_rate, channel_count, channel_map);
		}
		/* else
			if (cfg_.is_no_resample(sample_rate))
				return true; //can we be here? No. */
	}

	in_samples_accum_ += sample_count;
	while(1)
	{
		in_samples_used = sample_count; out_samples_gen = buf_samples;
		spxs_error = speex_resampler_process_interleaved_float(spxs_state_, current, &in_samples_used, buffer_, &out_samples_gen);
		if (spxs_error) { console::error(speex_resampler_strerror(spxs_error)); break; }

		sample_count -= in_samples_used;
		current += in_samples_used * channel_count_;

		out_samples_gen_accum_ += out_samples_gen;

		if (out_samples_gen != 0)
		{
			audio_chunk * out = insert_chunk(out_samples_gen*channel_count_);
			out->set_data(buffer_, out_samples_gen, channel_count_, cfg_.outRate, channel_map_);
		}
		if (sample_count == 0/* && out_samples_gen == 0*/) break;
	}

	while (in_samples_accum_ > sample_rate_ && out_samples_gen_accum_ > (size_t)cfg_.outRate)
	{
		in_samples_accum_ -= sample_rate_;
		out_samples_gen_accum_ -= cfg_.outRate;
	}
	return false;
}

void dsp_spxs::flush()
{
	if (!spxs_state_) return;
	speex_resampler_reset_mem(spxs_state_); speex_resampler_skip_zeros(spxs_state_);
	in_samples_accum_ = out_samples_gen_accum_ = 0;
	return;
}

void dsp_spxs::flushwrite()
{
	size_t in_samples_used, out_samples_gen, sample_count;
	int spxs_error;
	if (!spxs_state_) return;
	sample_count = speex_resampler_get_input_latency(spxs_state_);

	while(1)
	{
		in_samples_used = sample_count; out_samples_gen = buf_samples;
		spxs_error = speex_resampler_process_interleaved_float(spxs_state_, NULL, &in_samples_used, buffer_, &out_samples_gen);
		if (spxs_error) { console::error(speex_resampler_strerror(spxs_error)); break; }
		sample_count -= in_samples_used;

		if (out_samples_gen != 0)
		{
			audio_chunk * out = insert_chunk(out_samples_gen*channel_count_);
			out->set_data(buffer_, out_samples_gen, channel_count_, cfg_.outRate, channel_map_);
		}
		if (sample_count == 0 && out_samples_gen == 0) break;
	}
	speex_resampler_reset_mem(spxs_state_); speex_resampler_skip_zeros(spxs_state_);
	in_samples_accum_ = out_samples_gen_accum_ = 0;
	return;
}

double dsp_spxs::get_latency()
{
	if (sample_rate_ && cfg_.outRate)
		return double(in_samples_accum_)/double(sample_rate_) - double(out_samples_gen_accum_)/double(cfg_.outRate);
	else return 0;
	// warning: sample_rate_ and out_rate_ can be from previous track,
	// but in_samples_accum_ == out_samples_gen_accum_ == 0,  so it's ok.
	
	// ?? return double(speex_resampler_get_input_latency(spxs_state_))/double(sample_rate_);
}
