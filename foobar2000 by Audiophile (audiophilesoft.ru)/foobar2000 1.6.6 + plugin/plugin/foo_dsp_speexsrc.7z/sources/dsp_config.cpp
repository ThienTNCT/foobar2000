/* Copyright (c) 2008-10 lvqcl.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 *
 * 3. The name of the author may not be used to endorse or promote products
 * derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */ 

#define _CRT_SECURE_NO_WARNINGS 1
#include "dsp_config.h"

const int STRMAXLEN = 20;

static const long samplerates[] = {8000, 11025, 16000, 22050, 24000, 32000, 44100, 48000, 64000, 88200, 96000, 176400, 192000};

static const TCHAR* qualities[] = {_T("0 (min)"), _T("1"), _T("2"), _T("3 (voip)"), _T("4"), _T("5 (desktop)"), _T("6"), _T("7"), _T("8"), _T("9"), _T("10 (max)"), };

t_dsp_spxs_params::t_dsp_spxs_params()
{
	cfg_.outRate        = 44100;
	cfg_.quality        = SPEEX_RESAMPLER_QUALITY_DESKTOP;
}

void t_dsp_spxs_params::get_spxsconfig(spxsConfig& cfg) const
{
	cfg_.CloneTo(cfg);
}

bool t_dsp_spxs_params::set_data(const dsp_preset& p_data)
{
	t_int32 temp[2];
	if (p_data.get_owner() != g_get_guid()) return false;
	if (p_data.get_data_size() != sizeof(temp))
	{
		return false;
	}
	memcpy(temp, p_data.get_data(), sizeof(temp));

	for(int i=0; i<2; i++)
		byte_order::order_le_to_native_t(temp[i]);
		
	cfg_.outRate        = temp[0];
	cfg_.quality        = temp[1];

	return true;
}

bool t_dsp_spxs_params::get_data(dsp_preset& p_data) const
{
	t_int32 temp[2];
	temp[0] = cfg_.outRate;
	temp[1] = cfg_.quality;

	p_data.set_owner(g_get_guid());
	for(int i=0; i<2; i++)
		byte_order::order_native_to_le_t(temp[i]);
	p_data.set_data(temp, sizeof(temp));
	return true;
}

void t_dsp_spxs_params::tset_outRate(const TCHAR* rate)
{
	set_outRate(_ttoi(rate));
}

const TCHAR* t_dsp_spxs_params::toutRateStr(TCHAR* buf) const
{
	_itot_s(cfg_.outRate, buf, STRMAXLEN-1, 10);
	return buf;
}


BOOL dialog_dsp_spxs::OnInitDialog(CWindow wndFocus, LPARAM lInitParam)
{
	TCHAR buf[15];

	CComboBox rateCombo(GetDlgItem(IDC_RATE));
	CComboBox qualCombo(GetDlgItem(IDC_QUALITY));
	
	rateCombo.LimitText(12);
	for(int i=0; i<sizeof(samplerates)/sizeof(samplerates[0]); i++)
	{
		_itot_s(samplerates[i], buf, 10);
		rateCombo.AddString(buf);
	}
	params_.toutRateStr(buf);
	for(int i=0; i<sizeof(samplerates)/sizeof(samplerates[0]); i++)
	{
		TCHAR buf2[15];
		_itot_s(samplerates[i], buf2, 10);
		if (!_tcscmp(buf2, buf)) { rateCombo.SetCurSel(i); break; }
	}
	rateCombo.SetWindowTextW(buf);

	for(int i=0; i<sizeof(qualities)/sizeof(qualities[0]); i++)
		qualCombo.AddString((qualities[i]));
	qualCombo.SetCurSel(params_.quality());

	return 0;
}

void dialog_dsp_spxs::OnCommand(UINT uNotifyCode, int nID, CWindow wndCtl)
{
	switch (nID)
	{
	case IDOK:
		{
			TCHAR str[STRMAXLEN];
			CComboBox rateCombo(GetDlgItem(IDC_RATE));
			CComboBox qualCombo(GetDlgItem(IDC_QUALITY));

			rateCombo.GetWindowTextW(str, STRMAXLEN);
			params_.tset_outRate(str);
			params_.set_quality(qualCombo.GetCurSel());

			// Data (potentially) changed
			EndDialog(IDOK);
		}
		break;

		case IDCANCEL:
		{
			// Data not changed
			EndDialog(0);
		}
		break;
	}
}
