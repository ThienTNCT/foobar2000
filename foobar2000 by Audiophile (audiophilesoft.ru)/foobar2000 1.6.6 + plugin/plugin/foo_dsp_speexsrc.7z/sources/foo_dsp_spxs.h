/* Copyright (c) 2008-10 lvqcl.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 *
 * 3. The name of the author may not be used to endorse or promote products
 * derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */ 

#ifndef FOODSPRATE_H
#define FOODSPRATE_H

#include "dsp_config.h"

class dsp_spxs : public dsp_impl_base_t<dsp_v2>
{
	spxsConfig cfg_;

	audio_sample* buffer_;

	size_t in_samples_accum_, out_samples_gen_accum_;

	unsigned sample_rate_;
	unsigned channel_count_;
	unsigned channel_map_;
	unsigned buf_channels_;

	SpeexResamplerState* spxs_state_;

	void init();
	bool set_data(const dsp_preset & p_data);
 
public:
	dsp_spxs();
	dsp_spxs(const t_dsp_spxs_params& params);
	~dsp_spxs();

private:
	void reinit(unsigned sample_rate, unsigned channel_count, unsigned channel_map);
	void flushwrite();

protected:
	virtual void on_endoftrack(abort_callback & p_abort);
	virtual void on_endofplayback(abort_callback & p_abort);
	virtual bool on_chunk(audio_chunk * chunk, abort_callback & p_abort);

public:
	virtual void flush();
	virtual double get_latency();
	virtual bool need_track_change_mark() { return false; }
};

#endif
