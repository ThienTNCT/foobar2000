/* Copyright (c) 2008-10 lvqcl.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 *
 * 3. The name of the author may not be used to endorse or promote products
 * derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */ 

#ifndef DSPSPXSCONFIG_H
#define DSPSPXSCONFIG_H

#include "../ATLhelpers/ATLhelpers.h"
#include "../SDK/foobar2000.h"

#include "speexsrc\speex_resampler.h"

#include "resource.h"



#define RESAMPLER_MAJOR_VERSION  0 /* Major version number */
#define RESAMPLER_MINOR_VERSION  1 /* Minor version number */
#define RESAMPLER_PATCH_VERSION  2 /* Patch level */
#define RESAMPLER_BUILD_VERSION  0 /* Build number */


#define RESAMPLER_VERSION (RESAMPLER_MAJOR_VERSION*0x10000 + RESAMPLER_MINOR_VERSION*0x100 + RESAMPLER_PATCH_VERSION)

#ifndef STR
#define STR__(x)  #x
#define STR(x)    STR__(x)
#endif

#if defined(RESAMPLER_ALPHA_VERSION)
#define RESAMPLER_VERSION_STR STR(RESAMPLER_MAJOR_VERSION)"."STR(RESAMPLER_MINOR_VERSION)"."STR(RESAMPLER_PATCH_VERSION)" alpha "STR(RESAMPLER_ALPHA_VERSION)
#elif defined(RESAMPLER_BETA_VERSION)
#define RESAMPLER_VERSION_STR STR(RESAMPLER_MAJOR_VERSION)"."STR(RESAMPLER_MINOR_VERSION)"."STR(RESAMPLER_PATCH_VERSION)" beta "STR(RESAMPLER_BETA_VERSION)
#else
#define RESAMPLER_VERSION_STR STR(RESAMPLER_MAJOR_VERSION)"."STR(RESAMPLER_MINOR_VERSION)"."STR(RESAMPLER_PATCH_VERSION)
#endif

class spxsConfig
{
public:
	t_int32 outRate;
	t_int32 quality;

	bool is_no_resample(unsigned in_samplerate) const
	{
		if (in_samplerate == outRate) return true;
		return false;
	}

	void CloneTo(spxsConfig& to) const
	{
		to.outRate = outRate;
		to.quality = quality;
	}
};

class t_dsp_spxs_params
{
	spxsConfig cfg_;
public:	
	t_dsp_spxs_params();
	t_dsp_spxs_params(const spxsConfig& cfg):cfg_(cfg){}
	void get_spxsconfig(spxsConfig& cfg) const;

	static const GUID &g_get_guid()
	{ // {E60B29C8-6AD2-4d27-9A44-394AB105DA4D}
		static const GUID guid = { 0xe60b29c8, 0x6ad2, 0x4d27, { 0x9a, 0x44, 0x39, 0x4a, 0xb1, 0x5, 0xda, 0x4d } };
		return guid;
	}

	//store data from preset
	bool set_data(const dsp_preset& p_data);
	//put data to preset
	bool get_data(dsp_preset& p_data) const;

	//inline t_int32 outRate(...) const { return cfg_.outRate; }
	inline t_int32 quality() const { return cfg_.quality; }
	const TCHAR* toutRateStr(TCHAR*) const;

	void tset_outRate(const TCHAR* rate);
	inline void set_outRate(t_int32 rate)
	{
		if (rate < audio_chunk::sample_rate_min) rate = audio_chunk::sample_rate_min;
		else if (rate > audio_chunk::sample_rate_max) rate = audio_chunk::sample_rate_max;
		cfg_.outRate = rate;
	}
	inline void set_quality(t_int32 q){ cfg_.quality = q; }
};

class dialog_dsp_spxs : public CDialogImpl<dialog_dsp_spxs>
{
public:
	enum
	{
		IDD = IDD_CONFIG
	};
 
	BEGIN_MSG_MAP_EX(dialog_dsp_spxs)
		MSG_WM_INITDIALOG(OnInitDialog)
		MSG_WM_COMMAND(OnCommand)
	END_MSG_MAP()

private:
	t_dsp_spxs_params& params_;

public:
	dialog_dsp_spxs(t_dsp_spxs_params& p_params) : params_(p_params) {}

protected:
	BOOL OnInitDialog(CWindow wndFocus, LPARAM lInitParam);
	void OnCommand(UINT uNotifyCode, int nID, CWindow wndCtl);
};

#endif
