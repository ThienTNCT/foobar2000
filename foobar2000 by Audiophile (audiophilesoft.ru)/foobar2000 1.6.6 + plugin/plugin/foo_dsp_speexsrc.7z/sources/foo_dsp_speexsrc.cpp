/* Copyright (c) 2008-10 lvqcl.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 *
 * 3. The name of the author may not be used to endorse or promote products
 * derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */ 

#include "foo_dsp_spxs.h"
#include "dsp_config.h"

class dsp_spxs_entry : public resampler_entry
{
public:
	dsp_spxs_entry() {};
	virtual void get_name(pfc::string_base& p_out) { p_out.set_string("Resampler (Speex)"); }
	virtual GUID get_guid() { return t_dsp_spxs_params::g_get_guid(); }
	virtual bool have_config_popup() { return true; }
	virtual float get_priority() { return 0.5f; }
	virtual bool is_conversion_supported(unsigned int src_srate, unsigned int dst_srate) { return 1; }

	virtual bool get_default_preset(dsp_preset& p_out);
	virtual bool create_preset(dsp_preset& p_out, unsigned p_target_srate, float p_qualityscale);
	
	virtual bool instantiate(service_ptr_t<dsp>& p_out, const dsp_preset& p_preset);

	virtual bool show_config_popup(dsp_preset& p_data, HWND p_parent);
};

bool dsp_spxs_entry::get_default_preset(dsp_preset& p_out)
{
	t_dsp_spxs_params().get_data(p_out);
	return true;
}

bool dsp_spxs_entry::create_preset(dsp_preset& p_out, unsigned p_target_srate, float p_qualityscale)
{
	t_dsp_spxs_params params;
	
	params.set_outRate(p_target_srate);
	params.set_quality(int(p_qualityscale*10));

	params.get_data(p_out);

	return true;
}

bool dsp_spxs_entry::instantiate(service_ptr_t<dsp>& p_out, const dsp_preset& p_preset)
{
	bool ret = false;
	if(p_preset.get_owner() == get_guid())
	{
		t_dsp_spxs_params params;
		params.set_data(p_preset);
		p_out = reinterpret_cast<dsp*>(new service_impl_t<dsp_spxs>(params));
		ret = p_out.is_valid();
	}
	return ret;
}

bool dsp_spxs_entry::show_config_popup(dsp_preset& p_data, HWND p_parent)
{
	t_dsp_spxs_params params;
	if (params.set_data(p_data))
	{
		dialog_dsp_spxs dlg(params);
		if(dlg.DoModal(p_parent) == IDOK)
		{
			params.get_data(p_data);
			return true;
		}
	}
	return false;
}

DECLARE_COMPONENT_VERSION(
	"Speex resampler",
	RESAMPLER_VERSION_STR,
	"Uses Speex resampling algorithm\n"
	"DSP plug-in for foobar2000 1.0+ written by lvqcl.\n\n"
);

//VALIDATE_COMPONENT_FILENAME("foo_dsp_speexsrc.dll");

static service_factory_t<dsp_spxs_entry>	foo_dsp_spxs;
