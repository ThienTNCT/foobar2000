#if 0
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <intrin.h>
extern int haveSSE;

BOOL WINAPI DllMain(HINSTANCE hinstDll, DWORD fdwReason, LPVOID lpvReserved)
{
	if (fdwReason == DLL_PROCESS_ATTACH)
	{
		int info[4];
		__cpuid(info, 1);

		haveSSE = info[3] & (1 << 25);
		//if (!haveSSE) return FALSE;
	}
	return TRUE;
}

int haveSSE = 0;
#endif